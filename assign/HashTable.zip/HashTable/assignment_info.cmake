
############################################################
# Assignment specific info
############################################################
set(COURSE_NAME "CS 350")
set(TERM "Fall")
set(PROJECT_NUMBER "assign08")
set(PROJECT_NAME HashTable)
